<?php
require 'layout.php';
?>
</body>
</html>
